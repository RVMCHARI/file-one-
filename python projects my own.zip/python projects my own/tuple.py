charytuple=(input("enter anything"))
x=(input("enter"))
if x in charytuple:
	print("yes,'apple' in the list")
else:
        print("noo")