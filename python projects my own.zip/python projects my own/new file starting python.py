Python 3.7.2 (tags/v3.7.2:9a3ffc0492, Dec 23 2018, 22:20:52) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print(id)
<built-in function id>
>>> print(address)
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    print(address)
NameError: name 'address' is not defined
>>> print(10)
10
>>> a=10
>>> b=20
>>> print(c)
Traceback (most recent call last):
  File "<pyshell#7>", line 1, in <module>
    print(c)
NameError: name 'c' is not defined
>>> print(a=b)
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    print(a=b)
TypeError: 'a' is an invalid keyword argument for print()
>>> print(a+b)
30
>>> 
>>> 
>>> print(variable)
Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    print(variable)
NameError: name 'variable' is not defined
>>> print(keyword.kwlist)
Traceback (most recent call last):
  File "<pyshell#13>", line 1, in <module>
    print(keyword.kwlist)
NameError: name 'keyword' is not defined
>>> input (keywords)
Traceback (most recent call last):
  File "<pyshell#14>", line 1, in <module>
    input (keywords)
NameError: name 'keywords' is not defined
>>> print(keyword, kwlist)
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    print(keyword, kwlist)
NameError: name 'keyword' is not defined
>>> 
