a = int(input("enter first number"))
b = int(input("enter second number"))
quotient = a // b
remainder = a % b
print("quotient", quotient)
print("remainder", remainder)
