def my_fun(food):
    for i in food:
        n=1
        print(n,".",i)
        n=n+1
fruits =["fgdfdf","dgsdgfd","dsgsdg","fdbgdf"]
my_fun(fruits)

