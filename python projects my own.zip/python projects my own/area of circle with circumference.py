r=float(input("radius of circle"))
pi=3.142
area=pi *(r*r)
circumference=2*pi*r
print("area of a circle" , area)
print("circumference of circle", circumference)

##
##radius of circle5
##area of a circle 78.55
##circumference of circle 31.419999999999998
