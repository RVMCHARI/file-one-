my_emp={"hr":{101,102,103,104},"admin":{105,106,107,108}}
for i in my_emp:
    print(i)
for i in my_emp.keys():
    print ("keys", i)

for x in my_emp.values():
    print("values",x)
    
for y in my_emp.items():
    print("items",y)
    

    
