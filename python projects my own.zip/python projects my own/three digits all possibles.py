a=int(input("enter any number"))
b=int(input("enter any number"))
c=int(input("enter any number"))
e=int(input("enter any number"))
d=[]
d.append(a)
d.append(b)
d.append(c)
d.append(e)
for i in range(0,4):
    for j in range(0,4):
        for k in range(0,4):
            for m in range(0,4):
                if[i!=j&j!=k&k!=m&m!=i]:
                    print(d[i],d[j],d[k],d[m])

print(d)

