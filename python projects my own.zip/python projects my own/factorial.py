num=int(input("enter any number"))
fact=1
if num<0:
    print("negative number not alowed")
elif num==0:
    print("factorial 0 is 1")
else:
    for i in range (1,num+1):
        fact=fact*i
        print("the factorial of ", num, "is", fact)
##enter any number5
##the factorial of  5 is 1
##the factorial of  5 is 2=(2*1)
##the factorial of  5 is 6=(3*2)
##the factorial of  5 is 24=(4*6)
##the factorial of  5 is 120=(5*24)
