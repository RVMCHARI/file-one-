class bank:
    def __init__(self,loc="",b_name="",fundtransfer=0):
        self.bank_name=b_name
        self.location=loc
        self.fundtransfer=fundtransfer
    def display(self):
        print ("banklocation is :", self.location)
        print("bank name is:", self.bank_name)
        print( self.fundtransfer)
    def withdrawn(self):
        print("money withdrawn fron ", self.bank_name,"bank")
class online_bank(bank):
    def __init__ (self,u_name="",fundtransfer=0):
        super().__init__(fundtransfer)
        self.u_name=u_name
        self.password="1234"
    def display(self):
        print(self.u_name)
        print(self.password)
        print(self.fundtransfer)
class ATM(online_bank):
     def __init__ (self,pin, cardno,fundtransfer=0):
        super().__init__(fundtransfer)
        self.pin=pin
        self.cardno=cardno
     def display(self):
         print("money withdrawn fron ", self.bank_name,"bank")
        
