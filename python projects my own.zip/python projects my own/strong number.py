##a=int(input("enter no of students"))
##print(students,"a")
##    for m in (months):
##        print(m)
a,b,c,d,e = 3, 2, 2.0, -3, 10
import operator
operator.div(a, b)
operator._ _div_ _(a,b)