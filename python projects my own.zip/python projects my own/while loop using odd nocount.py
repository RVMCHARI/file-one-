def dbgprint(x):
    if debug==True:
        print(x)
debug = False
r1 = int (input("enter the strting range value?"))
r2 = int (input("enter theending range value?"))
dbgprint("Range: %d - %d" % (r1, r2))
num =r1 + 1
count =0
while num< r2:
    dbgprint(" num: %d" %(num))
    res = num % 2
    dbgprint("res: %d" % (res))
    if (num % 2)>0:
           count += 1
    num += 1
print ("odd count : %d" % (count))
