##def recur_fibo(n):
##    if n<=1:
##        return n
##    else:
##        return(recur_fibo(n-1)+recur_fibo(n-2))
##    n=int(input("how many times?"))
##    if nterm<=0:
##        print("please enter a positive integer")
##    else:
##        print("fibonacci sequence:")
##        for i in range(nterm):
##            print(fibo_recur(i))
            
n=int(input("enter number of digits you want in series(minimum):"))
first=0
second=1
print("fibonacci series is")
print(first,",",second, end=",")
for i in range ( 0,n):
    next= first + second
    print(next, end =",")
    first=second
    second=next
