class emp:
    def __init__ (self, empid=0,empname="unknown",empsalary=0,empage=0):
        self.id=empid
        self.name=empname
        self.b_salary=empsalary
        self.age=empage
    def set(self,empage):
        if(empage<=60 or empage>=18):
            print("entered age not valid")
    def getid(self):
        return self.id
    def setid(self):
        self.setid=empid
    def getname(self):
        return self.name
    def setname(self):
        self.name=empname
    def getb_salary(self):
        return self.b_salary
    def setb_salary(self):
        self.b_salary=empsalary
    def getage(self):
        return self.age
    def setage(self):
        self.age=empage
    def display_emp(self):
        print("employee name:",self.getname())
        print("employee id:",self.getid())
        print("employee basic salary:",self.getb_salary())
        print("employee age:",self.getage())
