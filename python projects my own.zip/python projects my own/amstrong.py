n=int (input("enter no "))
a=n
r=0
while (n>0):
    k=n%10
    r=r+k**3
    n=n//10
if(a==r):
    print ("amstrong")
else:
    print("not Amstrong")
