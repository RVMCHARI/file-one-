pcitems={"cpu :":10000,"pendrive :":600,"monitor :":3000,"printer :":12000,"keyboard :":1000,"mouse :":600,"ups:":1900}
inlist=[]
bill=0
op=1
##def __init__(self,pcitems):
print( " *********WELCOME TO CHARI MALL******")
##    self.cpu=cpu
##    self.pendrive=pendrive
##    self.monitor=monitor
##    self.printer=printer
##    self.keyboard=keyboard
##    self.mouse=mouse
##    self.ups=ups
while( op>0 and op<8 ):
    n=1
    print ("o.exit menu")
    for i in pcitems.items() :
        print (n,".",i)
        n=n+1
    op=int(input("enter your option."))
    if(op==1):
        qn= int(input("no of the quantity"))
        inlist.append("cpu")
    elif(op==2):
        qn= int(input("no of the quantity"))
        inlist.append("pendrive")
    elif(op==3):
        qn= int(input("no of the quantity"))
        inlist.append("moniter")
    elif(op==4):
        qn= int(input("no of the quantity"))
        inlist.append("printer")
    elif(op==5):
        qn= int(input("no of the quantity"))
        inlist.append("keyboard")
    elif(op==6):
        qn= int(input("no of the quantity"))
        inlist.append("mouse")
    elif(op==7):
        qn= int(input("no of the quantity"))
        inlist.append("ups")
    else:
        print("selected items")
print( inlist )
print()
print(" Your selected items are...")
for i in inlist:
    print(i, qn)
    t=" "
    t=pcitems.get(i)
    if (t!=" "):
        bill += t
print ("total bill is:", bill," rupees")
gst=bill*0.1
print("gst is:",gst)
dis=bill*0.12
print("discountis:",dis)
net=bill+gst-dis
print("Net Amount is :",net)
    
        
    
    
