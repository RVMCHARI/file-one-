def squaresum(n):
    sm=0
    for i in range(1, n+1):
        sm=sm+(i*i)
    return sm
##>>> n=4
##>>> print(squaresum(n))
##30
##>>>
def cubesum(n):
    sum=0
    for i in range(1, n+1):
        sum=sum+(i*i*i)
    return sum
##>>> n=4
##>>> print(cubeum(n))
##100
##>>>
