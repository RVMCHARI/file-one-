bill=int(input('enter the bill amount'))
discount =0
if bill<=10000:
     discount=10
     output = bill - (bill * discount / 100)
##        print('discount bill amount;', output)
elif(bill>=10000)and(bill<=20000):
        discount=20
        output = bill - (bill * discount / 100)
##        print('discount bill amount;',output)
elif bill>20000:
        discount=20
        output = bill - (bill * disco
##        print('discount bill amount;', output)
print('discont amount;,', outpu
##print(
##bill = int(input("Enter bill amoun
###discount = int(input("Enter discount percentage:
##disco
##    output = bi
##    print("After discount your bill is: ", output)
##elif (bill>=10001 and bill<=20000):
##    discount=20
##    output = bill - (bill * discount / 100)
##    print("After discount your bill is: ", output)
##elif( bill>20000):
##    discount=25 
##    output = bill - (bill * discount / 100)                    
##    print("After discount your bill is: ", output)
##    

