def counting():
    number=int(input("enter a number "))
    count=0
    while(number>0):
        number=number//10
        count=count+1
    print("\n total number of digits:", count)
##    if (number<1000):
##        number=(number//1000)
##        print(thousand)
##        hundread=(number//100)
##        print(hundread)
##        ten=(number//10)
##        print(ten)
##        one=(number//1)
##        print(one)
