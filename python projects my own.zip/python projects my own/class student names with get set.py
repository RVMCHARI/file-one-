class std:
    def __init__(self,stdid=0,stdname="unknown",maths=0,c=0,python=0):
        self.id=stdid
        self.name=stdname
        self.maths=maths
        self.c=c
        self.python=python
        self.total=maths+c+python
    def stdid(self):
            if(self
    def getpython(self):
        return self.python
    def setpython(self):
        self.python=python
    def gettotal(self):
        return self.total
    def settotal(self):
        self.total=total
    def getmaths(self):
        return self.maths
    def setmaths(self):
        self.maths=maths
    def printstd(self):
        print("stdname :", self.getname())
        print("stdid:", self.getid())
        print("stdc :", self.getc())
        print("stdpython :", self.getpython())
        print("stdmaths :", self.getmaths())
        print("stdtotal :", self.gettotal())

                    
                    
