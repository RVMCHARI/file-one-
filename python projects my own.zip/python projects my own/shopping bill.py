pcitems={"cpu":10000,"pendrive":600,"monitor":3000,"printer":12000,"keyboard":1000,"mouse":600,"ups":1900}
inlist=[]
bill=0
op=1
while( op>0 and op<8 ):
    n=1
    print ("o.exit menu")
    for i in pcitems.keys():
        print(n,".",i)
        n=n+1
    op=int(input("enter your option."))
    if(op==1):
        inlist.append("cpu")
        print ("cpu")
    elif(op==2):
        inlist.append("pendrive")
        print ("pendrive")
    elif(op==3):
        inlist.append("moniter")
    elif(op==4):
        inlist.append("printer")
    elif(op==5):
        inlist.append("keyboard")
    elif(op==6):
        inlist.append("mouse")
    elif(op==7):
        inlist.append("ups")
    else:
        print("selected items")
print( inlist )
print()
print(" Your selected items are...")
for i in inlist:
    print(i, )
    t=" "
    t=pcitems.get(i)
    if (t!=" "):
        bill+=t
print ("total bill is:", bill," rupees")
gst=bill*0.1
print("gst is:",gst)
dis=bill*0.12
print("discountis:",dis)
net=bill+gst-dis
print("Net Amount is :",net)
    
        
    
    
