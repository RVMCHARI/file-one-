a=eval(input("enter any number"))
def listprint():
    for i in a:
        if (i%2==0):
            print("evennumber : ", i)
        if(i%2==1):
            print("odd number:", i)

