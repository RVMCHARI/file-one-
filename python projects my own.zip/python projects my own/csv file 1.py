import csv
path = "F:\data\google_stock_data.csv"
file = open(path,newline="")
reader = csv.reader(file)
heaer = next(reader)#the firstline is the header
data = [row for row in reader]#read the
print (header)
print (data[0])
