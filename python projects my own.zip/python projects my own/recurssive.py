def  recursive(number):
    first=0
    second=1
    print(first)
    print(second)
    i=2
    for i in range(i,number):
        thirdno=first+second
        print(thirdno)
        first=second
        second=thirdno
