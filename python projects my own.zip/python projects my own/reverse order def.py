def listprint(a):
    reverse=0
    while(a>0):
        r=a%10
        reverse=(reverse*10)+r
        n=n//10
        print("reverse", reverse)
