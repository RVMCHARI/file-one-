a=int(input("enter a number"))
i=1
while(i<a):
    if (a%i==0):
        print(i)
    i=i+1
