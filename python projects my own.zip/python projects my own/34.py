Python 3.7.2 (tags/v3.7.2:9a3ffc0492, Dec 23 2018, 22:20:52) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> x=[1,2,3[4,5,6],7,8,9]
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    x=[1,2,3[4,5,6],7,8,9]
TypeError: 'int' object is not subscriptable
>>> x=name
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    x=name
NameError: name 'name' is not defined
>>> x=1324235
>>> printX
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    printX
NameError: name 'printX' is not defined
>>> print(x)
1324235
>>> x=[1,2,[3,4,5],6,7]
>>> print x[2]
SyntaxError: Missing parentheses in call to 'print'. Did you mean print(x[2])?
>>> 
