class oyo_booking:
        def __init__(self,add="",c_name="",mobile_no=0,indate="",inlist="",inlist2="",inlist3="",outdate="",rno=101,bill=0,bill2=0,bill3=0):
                print("********Welcome to OYO Booking******")
                self.name=c_name
                self.add=add
                self.mobile_no=mobile_no
                self.outdate=outdate
                self.indate=indate
                self.rno=rno
                self.bill=bill
                self.bill2=bill2
                self.bill3=bill3
                self.inlist2=inlist2
                self.inlist=inlist
                self.inlist3=inlist3
        def inputdata(self):
                self.name=input("Enter your name")
                self.add=input("Enter your address")
                self.indate=input("Enter your in date")
                self.outdate=input("Enter your out date")
                self.mobile_no=input("Enter your mobile no")
                print("Your room no.:",self.rno)
        def restaurent(self):
                print("********Welcome to Chari Restaurent******")
                menu={"Roti:":25,"biryani:":300,"Masala kulcha:":280,"Water bottle:":20,"drink:":25,"mutton biryani:":490,"chicken biryani:":390}
                self.inlist=[]
                bill=0
                self.bill=bill
                op=1
                while(op>0 and op<9):
                        n=1
                        print("0.exit menu")
                        for i in menu.keys():
                            print(n,".",i)
                            n=n+1
                        op=int(input("enter your choice"))
                        if (op==1):
                            self.inlist.append("Roti:")
                        elif (op==2):
                            self.inlist.append("biryani:")
                        elif (op==3):
                            self.inlist.append("Masala kulcha:")
                        elif (op==4):
                            self.inlist.append("Water bottle:")
                        elif (op==5):
                            self.inlist.append("drink:")
                        elif (op==6):
                            self.inlist.append("mutton biryani:")
                        elif (op==7):
                            self.inlist.append("chicken biryani:")
                        elif(op==8):
                                break;
                        else:
                            print("selected items")
                print(self.inlist)
                print()
                print(" Your selected items are...")
                for i in self.inlist:
                    print(i)
                    t=" "
                    t=menu.get(i)
                    if (t!=" "):
                        bill+=t
                        self.bill=bill
                print ("Restaurent total bill is:", bill)
               
        def roomrent(self):
                print ("*******room rent********")
                
                room={"Class-A":5000,"Class-B":4000,"Class-C":3000,"Class-D":2000}
                self.inlist2=[]
                bill2=0
                self.bill2=bill2
                op1=1
                while (op1>0 and op1<6):
                        n=1
                        print("0.exit menu")
                        for i in room.keys():
                            print(n,".",i)
                            n=n+1
                        op1=int(input("enter your choice"))
                        if (op1==1):
                            self.inlist2.append("Class-A")
                        elif (op1==2):
                            self.inlist2.append("Class-B")
                        elif (op1==3):
                            self.inlist2.append("Class-C")
                        elif (op1==4):
                            self.inlist2.append("Class-D")
                        elif(op1==5):
                                break;
                        else:
                           print("selected items")
                print(self.inlist2)
                print()
                print(" Your selected room is...")
                for r in self.inlist2:
                    print(r)
                    t=" "
                    t=room.get(r)
                    if (t!=" "):
                        bill2+=t
                        self.bill2=bill2
                print ("total room bill is:", bill2,)
  
        def carrent(self):
                print("*******car rent*******")
                car={"Hundai":5000,"Skoda":6000,"BMW":8000,"AUDI":1000,"Nissan":7000,"Swift Dzire":4000}
                self.inlist3=[]
                bill3=0
                self.bill3=bill3
                op2=1
                while(op2>0 and op2<8):
                        n=1
                        print("0.exit menu")
                        for i in car.keys():
                            print(n,".",i)
                            n=n+1
                        op2=int(input("enter your choice"))
                        if (op2==1):
                            self.inlist3.append("Hundai")
                        elif (op2==2):
                            self.inlist3.append("Skoda")
                        elif (op2==3):
                            self.inlist3.append("BMW")
                        elif (op2==4):
                            self.inlist3.append("AUDI")
                        elif (op2==5):
                            self.inlist3.append("Nissan")
                        elif (op2==6):
                            self.inlist3.append("Swift Dzire")
                        elif(op2==7):
                                break;
                        else:
                            print("selected car")
                print(self.inlist3)
                print()
                print(" Your selected car is...")
                for c in self.inlist3:
                    print(c)
                    t=" "
                    t=car.get(c)
                    if (t!=" "):
                                bill3+=t
                                self.bill3=bill3
                print ("total car rent is:", bill3)
        def display(self):
                print("******WELCOME TO HOTEL*********")
                print("-------------------------------")
                print("********OYO Booking***********")
                print("------------------------------")
                print("Customer Booking Details:")
                print("--------------------------------")
                print("Customer Nmae:",self.name)
                print("Customer Mobile No:",self.mobile_no)
                print("Customer Address:",self.add)
                print("Customer in Date:",self.indate)
                print("Customer out Date:",self.outdate) 
                print("-------------------------------")
                print("Room Details:")
                print("---------------------------------")
                print("Alloted Room No:",self.rno)
                print(" Your selected room is...")
                print(self.inlist2)
                print ("total room bill is:", self.bill2,)
                print("-------------------------------------")
                print("Restaurent Details")
                print("----------------------------------")
                print(" Your selected items are...")
                print(self.inlist)
                print ("Restaurent total bill is:", self.bill)
                print("------------------------------------")
                print("Car Rent Details")
                print("-----------------------------------")
                print(" Your selected car is...")
                print(self.inlist3)                
                print ("total car rent is:", self.bill3)
                totalbill=self.bill+self.bill2+self.bill3
                print("--------------------------------------")
                print("TotalAmount is:",totalbill)
                gst=totalbill*0.1
                print("GST is:",gst)
                dis=totalbill*0.12
                print("Discountis:",dis)
                print("---------------------------------------")
                net=totalbill+gst-dis
                print("Net Amount to Payment is :",net)
                print("-------------------------------------")
                print("**********visit Again Thank You*************")



def main():

    a=oyo_booking()
    

    while (1) :
        print("1.Enter Customer Data")
        
        print("2.Calculate restaurent bill")

        print("3.Calculate roomrent")

        print("4.Calculate Carrent")

        print("5.Show total cost")

        print("6.EXIT")

        b=int(input("Enter your choice:"))
        if (b==1):
            a.inputdata()

        if (b==2):

            a.restaurent()

        if (b==3):

            a.roomrent()

        if (b==4):

            a.carrent()

        if (b==5):

            a.display()

        if (b==6):

            quit()



main()








