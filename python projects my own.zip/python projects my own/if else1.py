x=int(input("enter five subjects total marks"))
if(x>500):
    print("input is wrong")
else:
     avg =x/5
     if((avg<100)and(avg>80)):
        print('avg, a grade')
     elif((avg<79)and(avg>60)):
             print('avg,b grade')
     elif((avg<59)and(avg>40)):
                 print('avg,c grade')
     else:
        
        print('avg,d grade')
        
print ('thanking you')            
