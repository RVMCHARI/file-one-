n=int (input("enter any nu"))
a=[]
for i in range (2, n+1):
    if(n%i==0):
        a.append(i)
        print("smallest devisor" , a[0])
