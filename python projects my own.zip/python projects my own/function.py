def add (a,b):
    print(a,b)
##    sum=a+b
##    sub= a-b
##    return sub,sum
##a= int(input("enter first number"))
##b=int(input("enter second number"))
##res=add (a,b)
##res1=sub (a,b)
##print ("result=",res1,\n, res)

      
