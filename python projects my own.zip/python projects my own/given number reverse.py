num=int(input("enter any number"))
reverse=0
while (num>0):
    rem=num%10
    reverse=(reverse*10)+rem
    num=num//10
print("\n reverse of entered num is =%d"%reverse)
