x= "hello world \n pythn \n technologies"
print(x)
