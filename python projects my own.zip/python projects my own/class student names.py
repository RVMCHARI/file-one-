class std:
    def __init__(self,stdid=0,stdname="unknown",maths=0,c=0,python=0):
        self.id=stdid
        self.name=stdname
        self.maths=maths
        self.c=c
        self.python=python
        self.total=maths+c+python
    def stdid(self):
            if(self.id<0):
                pass
            else:
                self.id=sid
    def getid(self):
        return self.id
    def setid(self):
        s
        return self.totalgermomag
        self.total=totalhhdsaSSEE22
    def getmaths(self):
        return self.maths
    def setmaths(self):
        self.maths=maths
