n=int(input("enter a string"))
for i in range (0,len[n]):
    for j in range(0,len[n]-1):
        print(n[j],end="")
    print()
