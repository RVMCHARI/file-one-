x={1,3,5,79,8,5,3,2,2}
x.pop()
print(x)
print(type(x))
add(52,25,45,)