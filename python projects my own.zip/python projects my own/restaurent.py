print("********Welcome to Chari Restaurent******")
menu={"Roti:":25,"biryani:":300,"Masala kulcha:":280,"Water bottle:":20,"drink:":25,"mutton biryani:":490,"chicken biryani:":390}
inlist=[]
bill=0
op=1
while(op>0 and op<8):
        n=1
        print("0.exit menu")
        for i in menu.keys():
            print(n,".",i)
            n=n+1
        op=int(input("enter your choice"))
        if (op==1):
            inlist.append("Roti:")
        elif (op==2):
            inlist.append("biryani:")
        elif (op==3):
            inlist.append("Masala kulcha:")
        elif (op==4):
            inlist.append("Water bottle:")
        elif (op==5):
            inlist.append("drink:")
        elif (op==6):
            inlist.append("mutton biryani:")
        elif (op==7):
            inlist.append("chicken biryani:")
        else:
            print("selected items")
print(inlist)
print()
print(" Your selected items are...")
for i in inlist:
    print(i)
    t=" "
    t=menu.get(i)
    if (t!=" "):
        bill+=t
print ("total bill is:", bill," rupees")
gst=bill*0.1
print("gst is:",gst)
dis=bill*0.12
print("discountis:",dis)
net=bill+gst-dis
print("Net Amount is :",net)
    #when u r giving in lis then u r append will be same not changesss
