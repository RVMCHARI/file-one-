name=input("enter anything")
i=0
for i in name:
    j=0
    print("name [",j,"] =" , i )
j=j++len(name)


