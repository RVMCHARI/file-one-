
def fibo_series():
    a=int(input("enter how many series u want"))
    first=0
    second=1
    print("fibo _series")
    print(first)
    print(second)
    i=2
    for i in range(i,a):
        third = first+second
        print(third)
        first = second
        second = third