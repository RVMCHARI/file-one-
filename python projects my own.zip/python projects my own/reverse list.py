from typing import List


def revlist():
    a: List[int] = [2, 3, 4, 5, 6, 7, 8]
    i = 0
    while (i < 7):
        print("a[", i, "]=", a[i])
        i = i + 1
    print("reverse")
    i = 6
    while (i >= 0):
        print("a[", i, "]", a[i])
        i = i - 1
    i = 6
    while (i >= 0):
        print("a[", i, "]", a[i])
        i = i - 1
    i=-7
    while ( i > 0 ):
        print("a[", i, "]", a[i])
        i = i-1
##>>> revlist()
##a[ 0 ]= 2
##a[ 1 ]= 3
##a[ 2 ]= 4
##a[ 3 ]= 5
##a[ 4 ]= 6
##a[ 5 ]= 7
##a[ 6 ]= 8
##reverse
##a[ 6 ] 8
##a[ 5 ] 7
##a[ 4 ] 6
##a[ 3 ] 5
##a[ 2 ] 4
##a[ 1 ] 3
##a[ 0 ] 2
