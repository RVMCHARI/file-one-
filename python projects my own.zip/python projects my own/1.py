a=int(input( 'enter a number'))
sum=0
t=a
f=1
c=0
while(a!=0):
    rem=a%10
    c=a//10
    a=c
    if(rem == 0):
        rem=1
    else:
        f=1
while(rem!=0):
    f=f*rem
    rem=rem-1
    sum=sum+f
    if(sum==t):
        print("strong number")
    else:
         print("not a strong number")