num=int(input("enter a number"))
t=num
r=0
na=0
while(num!=0):
    r=num%10
    num
    na=na*10+r
if(na==t):
    print("given number palendrome")
else:
    print("given number")