num=int(input("enter any number"))
print(num)
thou=int((num//1000))
print(thou ,)
hun=int((num//100))
print(hun)
ten=int((num//10))
print(ten)
one=int(num//1)
print(one)
##n=int(input(""))
##for i in range (0,5):
##    for j in range (0,len(n)-i):
##        print(n(j),end="")
