for letter in 'Python': # First Example
    print ('Current Letter :', letter)
fruits = ['banana', 'apple', 'mango']
for fruit in fruits:# Second Example
    print ('Current fruit :', fruit)
    print ("good bye")
i=0
j=0
d=0
x = lambda i:i*10
print(x(2))

str = "this-is-real-string-example....wow!!!";
print ("Min character: " + min(str)+max(str))
