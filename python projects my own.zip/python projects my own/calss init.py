class person:
    def __init__(self,name=" ",idcardno=0):
        self.name=name
        self.card=idcardno
    def display(self):
        print(self.name,self.card)
class patient(person):
    def __init__(self,name=" ",age=0,sex=" ",idcardno=0):
        super().__init__(name,idcardno)
        self.age=age
        self.sex=sex
    def displaypatient(self):
        print(self.name)
        print(self.age)
        print(self.sex)
        print(self.card)
        
        
    
##>>> obj=patient("hfjgfg",45,"gjdf",547457)
##>>> obj.displaypatient()
##>>> obj=person("fhdf",46346)
##>>> obj.display()
##fhdf 46346
