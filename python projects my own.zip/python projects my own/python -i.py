n = int (input("enter no"))
a=[]
for i in range (2, n+1):
  if n%i == 0:
    a.append(i)
    print ('smallest divisor', a[0])