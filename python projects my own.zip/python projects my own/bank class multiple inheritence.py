class bank:
    def __init__(self,loc="",b_name="",ifsc=0):
        self.bank_name=b_name
        self.location=loc
        self.ifsc=ifsc
    def ft(self):
        print ("money transfered by ", self.bank_name,"Bank Successfully")
    def withdrawn(self):
        print("money withdrawn fron ", self.bank_name,"bank")
class online_bank(bank):
    def __init__ (self,u_name="",loc="",b_name="",ifsc=0):
        super().__init__(loc,b_name,ifsc)
        self.username=u_name
        self.password="1234"
    def ft(self):
        print("fund transfered successfully by online", self.bank_name,"Bank")
    def withdrawn (self):
        print("money transfered by online", self.bank_name,"bank", "By user ",self.username)
        super().ft()
class ATM(bank):
    def __init__(self,c_no=0,u_name=""):
        super().__init__(u_name)
        self.atmcardno=c_no
        self.pwd="1234"
    def ft(self):
        print("money Transfered by", self.bank_name," bank successfully")
    def withdrawn (self):
        print("money withdrawn by", self.bank_name,"bank  ATM")
class credit_card(ATM):
    def __init__(self,c_no=0,loc="",b_name="",ifsc=0,u_name=""):
        super().__init__(loc,b_name,ifsc,u_name)        
        self.atmcardno=c_no
        self.pwd="1234"
    def ft(self):
        print("fund transfered successfuly by ", self.bank_name,"Bank ATM")
        print("money Transfered by", self.bank_name," bank successfully")
    def withdrawn (self):
        print("money withdrawn by", self.bank_name,"bank  ATM")
  
