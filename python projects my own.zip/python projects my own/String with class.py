name=""
i=0
for i in name:
    print("name[" ,j ,"], =" , i )
    j=j+1
