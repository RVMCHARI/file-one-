Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 21:26:53) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
1
2
3
4
5
6
7
8
9
10
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
1
3
5
7
9
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
1
4
7
10
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 1, in <module>
    for i in range (1,11,0):
ValueError: range() arg 3 must not be zero
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
1
2
3
4
5
6
7
8
9
10
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
0
1
2
3
4
5
6
7
8
9
10
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
11
12
13
14
15
16
17
18
19
20
21
22
23
24
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
11
13
15
17
19
21
23
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number12
a * i = 12
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number232
a * i = 232
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number9
a * i = 9
a * i = 18
a * i = 27
a * i = 36
a * i = 45
a * i = 54
a * i = 63
a * i = 72
a * i = 81
a * i = 90
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
>>> 
enter a number9
9 * i = 9
9 * i = 18
9 * i = 27
9 * i = 36
9 * i = 45
9 * i = 54
9 * i = 63
9 * i = 72
9 * i = 81
9 * i = 90
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
>>> 
enter a number9
9 * 1 = 9
9 * 2 = 18
9 * 3 = 27
9 * 4 = 36
9 * 5 = 45
9 * 6 = 54
9 * 7 = 63
9 * 8 = 72
9 * 9 = 81
9 * 10 = 90
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number10
10 * 1 = 10
10 * 2 = 20
10 * 3 = 30
10 * 4 = 40
10 * 5 = 50
10 * 6 = 60
10 * 7 = 70
10 * 8 = 80
10 * 9 = 90
10 * 10 = 100
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number2
>>> 2
2
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number200
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number241
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 2, in <module>
    rem==sum==0, f==0,t==a,c==0
NameError: name 'rem' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 13, in <module>
    sum=sum+f
TypeError: unsupported operand type(s) for +: 'builtin_function_or_method' and 'int'
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number1455
Traceback (most recent call last):
  File "C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py", line 15, in <module>
    if(t==sum):
NameError: name 't' is not defined
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
not a strong number
not a strong number
not a strong number
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
not a strong number
not a strong number
not a strong number
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
not a strong number
not a strong number
not a strong number
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
not a strong number
not a strong number
not a strong number
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number1455
not a strong number
not a strong number
not a strong number
not a strong number
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
not a strong number
not a strong number
not a strong number
>>> 
=== RESTART: C:\Users\user\AppData\Local\Programs\Python\Python37-32\1.py ===
enter a number145
>>> 
