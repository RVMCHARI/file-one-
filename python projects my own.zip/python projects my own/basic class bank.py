class bank:
    def __init__(self,loc="",b_name="",fundtransfer=0):
        self.bank_name=b_name
        self.location=loc
    def __ft__(self):
        print ("ft done by bank account :",self.bank_name)
    def __deposit__(self):
        print ("money deposited @ bank", self.location)
    def display(self):
        print ("account holder location is :", self.location)
        print ("account holder name is :", self.bank_name)
class ATM (bank):
    def __init__ (self,pin, cardno,username,b_name):
        super().__init__(username,b_name)
        self.pin=pin
        self.cardno=cardno
    def ft(self):
         print("ft intiated by ATM ", self.bank_name,"bank")
         super().ft()
class online_bank(bank):
    def __init__(self,u_name="",loc=0,fundtransfer=0):
        super().__init__(loc,fundtransfer)
        self.u_name=u_name
        self.password="1234"
    def display(self):
        print(self.u_name)
        print(self.password)
        super().ft()
