Python 3.7.2 (tags/v3.7.2:9a3ffc0492, Dec 23 2018, 22:20:52) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("helloworld")
helloworld
>>> a=2
>>> print(a)
2
>>> #
>>> b=8765684523
>>> print(b)
8765684523
>>> pi=3.14
>>> print()pi
SyntaxError: invalid syntax
>>> print(pi)
3.14
>>> c='A'
>>> print(c)
A
>>> name="ramadugu venu"
>>> print(name)
ramadugu venu
>>> q="true"
>>> print(q)
true
>>> x="none"
>>> pRint()x
SyntaxError: invalid syntax
>>> SyntaxError: invalid syntaxpRint()x
SyntaxError: invalid syntax
>>> print(x)
none
>>> 
>>> 0 = "x"
SyntaxError: can't assign to literal
>>> import keyword
>>> print(keyword.kwlist)
['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield']
>>> x
'none'
>>> y
Traceback (most recent call last):
  File "<pyshell#24>", line 1, in <module>
    y
NameError: name 'y' is not defined
>>> 9
9
>>> 9x
SyntaxError: invalid syntax
>>> has_0_in_it=
SyntaxError: invalid syntax
>>> has_0_in_it
Traceback (most recent call last):
  File "<pyshell#28>", line 1, in <module>
    has_0_in_it
NameError: name 'has_0_in_it' is not defined
>>> has_0_in_it=746588
>>> a=2
>>> type(a)
<class 'int'>
>>> print(type(a))
<class 'int'>
>>> a='fgfgf'
>>> type(a)
<class 'str'>
>>> a,b,c =1,2,3
>>> print(a,b,c)
1 2 3
>>> a,b=1,2,3
Traceback (most recent call last):
  File "<pyshell#37>", line 1, in <module>
    a,b=1,2,3
ValueError: too many values to unpack (expected 2)
>>> a,b,c =1,2
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    a,b,c =1,2
ValueError: not enough values to unpack (expected 3, got 2)
>>> a,b,_=1,2,3,4
Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    a,b,_=1,2,3,4
ValueError: too many values to unpack (expected 3)
>>> a=b=c=2
>>> print(a,b,c)
2 2 2
>>> print()b
SyntaxError: invalid syntax
>>> print(b)
2
>>> b= 4
>>> print(a,b,c)
2 4 2
>>> x=y=[7,8,9]
>>> x=[13,8,9]
>>> print(y)
[7, 8, 9]
>>> print(x)
[13, 8, 9]
>>> n=m=b=v=[6,8,0,8]
>>> m=[5,8,9,6]
>>> print(m)
[5, 8, 9, 6]
>>> print(b)
[6, 8, 0, 8]
>>> print(v)
[6, 8, 0, 8]
>>> m[0]=5
>>> print(m)
[5, 8, 9, 6]
>>> x=[1,2,[3,4,5],6,7]
print(x)




