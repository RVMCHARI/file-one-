def dbgprint(x):
   if debug==True:
       print(x)
debug = False
r1 = int (input("enter the strting range value?"))
r2 = int (input("enter theending range value?"))
dbgprint("Range: %d - %d" % (r1, r2))
num =r1 + 1
count =0
while num< r2:
   dbgprint(" num: %d" %(num))
   res = num % 2
   dbgprint("res: %d" % (res))
   if (num % 2)>0:
          count += 1
   num += 1
print ("odd count : %d" % (count))
num=(int(input("enter no")))
def while_else_demo():

    count = 0
    while count < 5 :
        num = int(input("Enter number between 0-100?"))
        if (num<0)or (num>100):
            print("aborted while: you've entered an invalid number.")
            break
        count += 1
    else:
        print("While loop ended gracefully.")
