##a=int(input("given number"))
##if (a<0):
##    print("Negative")
##else:
##        print("Positive")
##print("thank you")
####


##
##b= int(input ("a number"))
##if (b%2):
##    print("even")
##else:
##    print('odd')
##
##print ("thank you")



##num= float(input("enter a number"))
##if num>0:
##    print("positive")
##
##elif num==0:
##    print("zero")
##else:
##    print("negative")
##print('thank you')


a=int(input("enter first numbers:"))
b=int(input("enter second numbers:"))
if(a>b):
 print('large=a')
else:
 print('large=b')



##itemprice = float(input ("what is the price of the item"))
##percentagediscount = float (input ("what is thepercentage discount"))
##
##reducedprice = itemprice - itemprice*percentagediscount/100
##print("reduced price is " + str(reducedprice))
##













