def areacircle(r):
    pi=3.142
    return pi*(r*r)
##areacircle.py 
##>>> areacircle(4)
##50.272
##>>> 
