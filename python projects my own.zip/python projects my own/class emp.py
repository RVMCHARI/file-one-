class employee:
    def __init__(self,empid,empname,salary):
        self.empname = empname
        self.id=empid
        self.b_salary=salary
        self.name=empnmae
        self.g_sal=0
        
    def getemp(self):
        print ("i am in emp-->getemp()")
        def printemp(self):
            print ("i am in emp-->printemp")
            print("name", self.name,"\n id",self.id)
            print("basic sal", self.b_salary)
            print ("gross sal", self.g_sal)
        self.id=12
        self.name="Querty"
        print("i am in emp-->getemp()")
        def print emp(self):
              print("i am in emp-->print emp")
              print("name",self.name,"\n id ",self.id)
