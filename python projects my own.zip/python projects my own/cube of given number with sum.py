def sumofseries(n):
    sum = 0
##    if n%2 == 0:
##        sum =(n/2)*(n+1)
##    else:
##        sum= ((n+1)/2)*n
##    return (int(sum*sum))
    for i in range (1,n+1):
        sum+=i*i*i
        return sum
