def my_fun(x):
    return 5*x
print(my_fun(3))
print(my_fun(4))
print(my_fun(5))
print(my_fun(7))
print(my_fun(9))
